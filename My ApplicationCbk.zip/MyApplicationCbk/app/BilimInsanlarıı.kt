package com.example.myapplication222

object BilimInsanlarıı {
    val BilimInsanlarııList = listOf(
        TeknikDirector(
            imageResource = R.drawable.albert_einstein,albert.jpg,
            name = "Albert Einstein",
            info = "Albert Einstein was a German-born theoretical physicist who developed the theory of relativity, one of the two pillars of modern physics (alongside quantum mechanics). His work is also known for its influence on the philosophy of science. He is best known to the general public for his mass-energy equivalence formula E = mc^2, which has been dubbed 'the world's most famous equation'. He received the 1921 Nobel Prize in Physics for his 'services to theoretical physics'.\n\n" +
                    "Einstein was born in Ulm, in the Kingdom of Württemberg in the German Empire, on 14 March 1879. In 1905, at the age of 26, he published the special theory of relativity, which later became the foundation for general relativity. He continued to deal with problems of statistical mechanics and quantum theory, which led to his explanations of particle theory and the motion of molecules. He also investigated the thermal properties of light which laid the foundation of the photon theory of light. In 1917, he applied the general theory of relativity to model the structure of the universe. He received the Nobel Prize in Physics in 1921 for his theoretical physics contributions...",
            resAreas = listOf("Physics", "Quantum Mechanics", "Relativity Theory", "Cosmology")
        ),
        TeknikDirector(
            imageResource = R.drawable.marie_curie,Marie_Curie_c1920.jpg,
            name = "Marie Curie",
            info = "Marie Curie was a Polish and naturalized-French physicist and chemist who conducted pioneering research on radioactivity. She was the first woman to win a Nobel Prize, the first person and the only woman to win the Nobel Prize twice, and the only person to win the Nobel Prize in two scientific fields. Her discoveries included the techniques for isolating radioactive isotopes and the discovery of two elements, polonium and radium. Under her direction, the world's first studies were conducted into the treatment of neoplasms, using radioactive isotopes. She founded the Curie Institutes in Paris and in Warsaw, which remain major centres of medical research today...\n\n" +
                    "Curie was born in Warsaw, in partitioned Poland, in 1867. In 1891, at the age of 24, she followed her older sister Bronisława to study in Paris, where she earned her higher degrees and conducted her subsequent scientific work. She shared the 1903 Nobel Prize in Physics with her husband Pierre Curie and physicist Henri Becquerel. Her husband's death in 1906 left her as the sole winner of another Nobel Prize in Physics in 1911. She was the first woman to become a professor at the University of Paris...",
            resAreas = listOf("Physics", "Chemistry", "Radioactivity", "Nuclear Physics")
        ),
        TeknikDirector(
            imageResource = R.drawable.charles_darwin,darwin.jpg,
            name = "Charles Darwin",
            info = "Charles Darwin was an English naturalist, geologist, and biologist, best known for his contributions to the science of evolution. His proposition that all species of life have descended over time from common ancestors is now widely accepted, and considered a foundational concept in science. In a joint publication with Alfred Russel Wallace, he introduced his scientific theory that this branching pattern of evolution resulted from a process that he called natural selection, in which the struggle for existence has a similar effect to the artificial selection involved in selective breeding.\n\n" +
                    "Darwin was born in Shrewsbury, Shropshire, England, on 12 February 1809. He was educated at Shrewsbury School, then at the University of Edinburgh and the University of Cambridge. After graduating, he joined the crew of HMS Beagle, embarking on a five-year voyage to explore the coast of South America, and later, the Pacific Islands. This voyage provided him with the opportunity to study a wide range of organisms in diverse environments, leading him to formulate his theory of evolution...",
            resAreas = listOf("Evolutionary Biology", "Natural Selection", "Geology", "Taxonomy")
        ),
        TeknikDirector(
            imageResource = R.drawable.ada_lovelace,ada.jpg,
            name = "Ada Lovelace",
            info = "Ada Lovelace was an English mathematician and writer, chiefly known for her work on Charles Babbage's early mechanical general-purpose computer, the Analytical Engine. Her notes on the engine include what is now considered to be the first algorithm intended to be processed by a machine. Because of this, she is often regarded as the first computer programmer. Lovelace was also the only legitimate child of the poet Lord Byron and is remembered as a mathematical genius and a pioneer of computer science...\n\n" +
                    "Ada Lovelace was born on 10 December 1815 in London, England. From a young age, she showed an aptitude for mathematics and logic, encouraged by her mother. She corresponded with many prominent mathematicians and scientists of her time, including Charles Babbage, and her work was highly influential in the development of computing. Despite facing numerous obstacles as a woman in a male-dominated field, Lovelace made significant contributions to the early history of computers...",
            resAreas = listOf("Mathematics", "Computer Science", "Early Computing", "Algorithm Development")
        )
    )
}
