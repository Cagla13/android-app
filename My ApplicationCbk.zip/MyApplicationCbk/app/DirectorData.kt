package com.example.myapplicationcbk

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun DirectorData(adirector: TeknikDirector) {
    Column() {
        Image(
            painterResource(id = adirector.imageResource),
            contentDescription = "a tecnik director"
        )
        Row {
            Column() {
                Text(adirector.name, color = Color.White)

                Column {
                    for (ra in adirector.resAreas) {
                        Text(text = ra, color = Color.White);
                    }
                }

            }
            Text(text = adirector.info, color = Color.White)
        }
    }
}

@Composable
@Preview
fun DirectorDataPreview() {
    DirectorData(BilimInsanlari.BilimInsanlarııList[1])
}
