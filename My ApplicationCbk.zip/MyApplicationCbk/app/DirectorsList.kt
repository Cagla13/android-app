package com.example.myapplicationcbk

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapplication222.BilimInsanlarıı

@Composable
fun DirectorsList(slist: List<TeknikDirector>) {
    LazyColumn {
        items(slist) { adirector ->
            DirectorData(adirector)
        }
    }
}

@Composable
@Preview
fun DirectorListPreview() {
    DirectorsList(BilimInsanlarıı.BilimInsanlarııList)
}
