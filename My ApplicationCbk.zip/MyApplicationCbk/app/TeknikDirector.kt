package com.example.myapplicationcbk

import androidx.annotation.DrawableRes

data class TeknikDirector(
    @DrawableRes val imageResource: Int,
    val name: String,
    val info: String,
    val resAreas: List<String>
)
