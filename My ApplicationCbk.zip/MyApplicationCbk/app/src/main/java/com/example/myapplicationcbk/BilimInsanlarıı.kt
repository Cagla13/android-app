package com.example.myapplicationcbk


object BilimInsanlarıı {
    val BilimInsanlarııList = listOf(
        TeknikDirector(
            imageResource = R.drawable.albert,
            name = "Albert Einstein",
            info = "Albert Einstein was a German-born theoretical physicist who developed the theory of relativity, one of the two pillars of modern physics (alongside quantum mechanics). His work is also known for its influence on the philosophy of science. He is best known to the general public for his mass-energy equivalence formula E = mc^2, which has been dubbed 'the world's most famous equation'. He received the 1921 Nobel Prize in Physics for his 'services to theoretical physics'.\n\n",
            resAreas = listOf("Physics", "Quantum Mechanics", "Relativity Theory", "Cosmology")
        ),
        TeknikDirector(
            imageResource = R.drawable.marie_curie_c1920,
            name = "Marie Curie",
            info = "Marie Curie was a Polish and naturalized-French physicist and chemist who conducted pioneering research on radioactivity. She was the first woman to win a Nobel Prize, the first person and the only woman to win the Nobel Prize twice..\n\n",
            resAreas = listOf("Physics", "Chemistry", "Radioactivity", "Nuclear Physics")
        ),
        TeknikDirector(
            imageResource = R.drawable.darwin,
            name = "Charles Darwin",
            info = "Charles Darwin was an English naturalist, geologist, and biologist, best known for his contributions to the science of evolution. His proposition that all species of life have descended over time from common ancestors is now widely accepted, and considered a foundational concept in science. In a joint publication with Alfred Russel Wallace.\n\n",
            resAreas = listOf("Evolutionary Biology", "Natural Selection", "Geology", "Taxonomy")
        ),
        TeknikDirector(
            imageResource = R.drawable.ada,
            name = "Ada Lovelace",
            info = "Ada Lovelace was an English mathematician and writer, chiefly known for her work on Charles Babbage's early mechanical general-purpose computer, the Analytical Engine. Her notes on the engine include what is now considered to be the first algorithm intended to be processed by a machine. Because of this, she is often regarded as the first computer programmer. Lovelace was also the only legitimate child of the poet Lord Byron and is remembered as a mathematical genius and a pioneer of computer science...\n\n",
            resAreas = listOf("Mathematics", "Computer Science", "Early Computing", "Algorithm Development")
        )
    )
}
