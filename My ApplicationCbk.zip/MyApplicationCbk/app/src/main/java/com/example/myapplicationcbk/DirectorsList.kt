package com.example.myapplicationcbk

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController


@Composable
fun DirectorsList(slist: List<TeknikDirector>,navcont:NavHostController) {
    LazyColumn {
        items(slist) { adirector ->
            DirectorData(adirector, navcont)
        }
    }
}

