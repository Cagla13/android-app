package com.example.myapplicationcbk

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplicationcbk.BilimInsanlarıı.BilimInsanlarııList

enum class routes{
    first,
    secound,
    third,
    forth
}


@Composable
fun Controller(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = routes.first.name) {
        composable(route = routes.first.name) {
            DirectorData(adirector = BilimInsanlarııList[0],navController)
        }
        composable(route = routes.secound.name) {
            DirectorData(adirector = BilimInsanlarııList[1],navController)
        }
        composable(route = routes.third.name) {
            DirectorData(adirector = BilimInsanlarııList[2],navController)
        }
        composable(route = routes.forth.name) {
            DirectorData(adirector = BilimInsanlarııList[3],navController)
        }
    }
}
